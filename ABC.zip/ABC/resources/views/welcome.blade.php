<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>


        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">



    </head>
    <body>
      <br><br>
      <center>
         <div class="col-md-3">
         </div>
        <div class="alert alert-success col-md-6" role="alert">
          <h4 class="alert-heading">Bienvenido a ABC!</h4>

        </div>
        <div class="col-md-3">
        </div>

       <a href="{{ route('busqueda') }}"><button type="button" class="btn btn-primary btn-lg">Ver Catàlogo</button></a>
      </center>
     
    </body>
</html>
