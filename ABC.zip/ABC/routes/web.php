<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Ruta de Busqueda
Route::get('busqueda', 'CatalogoController@busqueda')->name('busqueda');
//ruta eliminar
Route::name('delete')->delete('/delete/{id}','CatalogoController@delete');
//Ruta para la alta
Route::POST('alta', 'CatalogoController@alta')->name('alta');
//Ruta para la modificacion
Route::name('update')->put('/update/{id}','CatalogoController@update');
