<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Catalogo;
use DB;

class CatalogoController extends Controller
{
  //busqueda
public function busqueda(){

       $resultado = \DB::table('tbl_catalogo')
         ->select('id','nombre','telefono','correo','activo','created_at')
         ->get();
    return view("catalogo")->with(['resultado'=>$resultado]);

  }

  //funcion de alta cotizacion
 public function alta(Request $request){

     $nombre = $request->nombre;
     $telefono = $request->telefono;
     $correo = $request->correo;
     $activo = $request->activo;

      $catalogo=new Catalogo;
      $catalogo->nombre=$request->nombre;
      $catalogo->telefono=$request->telefono;
      $catalogo->correo=$request->correo;
      $catalogo->activo=$request->activo;

      $catalogo->save();

      $notificacion = array(
      'message' => 'alta realizada con exito',
      'alert-type' => 'success');
      return redirect()->back()->with($notificacion);

  }

  //funcion eliminar
public function delete(Catalogo $id){
      $id->delete();
      $notificacion = array(
         'message' => 'eliminado con exito.',
         'alert-type' => 'error');
    return redirect()->back()->with($notificacion);

  }

  
  public function update(Catalogo $id,Request $request){


         $id->update(array(
           'nombre'=> $request->input('nombre'),
           'telefono'=> $request->input('telefono'),
           'correo'=> $request->input('correo')
         ));
          $notificacion = array(
         'message' => 'Editado con exito.',
         'alert-type' => 'info');
          return redirect()->back()->with($notificacion);
}

}
