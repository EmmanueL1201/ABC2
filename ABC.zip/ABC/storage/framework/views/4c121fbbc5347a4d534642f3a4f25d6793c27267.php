<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
    </head>
    <body>
      <br><br>
     <div class="container">
       <div class="row">
            <div class="col-lg-3">
              <div class="input-group">

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
              <div class="input-group">
                <input type="text" class="form-control" id="entradafilter" placeholder="Ingresa tu critero de Busqueda">
                <span class="input-group-btn">
                  <button class="btn btn-default" type="button">Buscador!</button>
                  <button class="btn btn-success" data-toggle="modal" data-target="#exampleModal20">Alta</button>
                </span>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-3">
              <div class="input-group">

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
         <br>
       <div class="row">

         <table class="table">
            <thead class="thead-light">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Telèfono</th>
                <th scope="col">Correo</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody class="contenidobusqueda">
             <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($res->id); ?></th>
                <td><?php echo e($res->nombre); ?></td>
                <td><?php echo e($res->telefono); ?></td>
                <td><?php echo e($res->correo); ?></td>
                <td>
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal30<?php echo e($res->id); ?>" data-whatever="@mdo">
                  <span class="glyphicon glyphicon-eye-open">Editar</span>
                  </button>
                  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal12<?php echo e($res->id); ?>" data-whatever="@mdo">
                  <span class="glyphicon glyphicon-ban-circle">Eliminar</span>
                  </button>
                </td>
                <!--modal para la modificacion-->
                  <div class="modal fade" id="exampleModal30<?php echo e($res->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                   <div class="modal-dialog" role="document">
                     <div class="modal-content">
                       <div class="modal-header" style="background:#2874A6;">
                         <h5 class="modal-title" id="exampleModalLabel" style="color:white;">Formulario de Modificación</h5>
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                       <div class="modal-body">
                         <form action="<?php echo e(route('update', ['id'=>$res->id])); ?>" method="POST">
                               <?php echo e(csrf_field()); ?>

                               <?php echo e(method_field('PUT')); ?>

                               <?php if(count($errors) > 0): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($error); ?> <br>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endif; ?>
                          <div class="form-group">
                             <label for="exampleInputEmail1">Nombre</label>
                             <input type="text" name="nombre" value="<?php echo e($res->nombre); ?>" class="form-control" id="exampleInputEmail1" required>
                             <!--<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
                           </div>
                           <div class="form-group">
                              <label for="exampleInputEmail1">Teléfono</label>
                              <input type="text" name="telefono" value="<?php echo e($res->telefono); ?>" class="form-control" id="exampleInputEmail1" required>
                              <!--<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
                            </div>
                           <div class="form-group">
                             <label for="exampleInputPassword1">Correo</label>
                             <input type="email" name="correo" value="<?php echo e($res->correo); ?>" class="form-control" id="exampleInputPassword1" required>
                           </div>

                           <button type="submit" class="btn btn-primary">Modificar</button>
                        </form>
                       </div>
                       <div class="modal-footer">


                       </div>
                     </div>
                   </div>
                 </div>
                <!--modal para la eliminacion-->
                  <div class="modal fade" id="exampleModal12<?php echo e($res->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                   <div class="modal-dialog" role="document">
                     <div class="modal-content">
                       <div class="modal-header" style="background:#d9534f;">
                         <h5 class="modal-title" id="exampleModalLabel" style="color:white;"></h5>
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                       <div class="modal-body">
                         <div class="col-lg-12 mt-5">
                              <div class="card">
                                  <div class="card-body">
                                      <center><p><h2>¿Seguro que desea eliminar?</h2></p></center><br>

                             <form action="<?php echo e(route('delete',['id'=>$res->id])); ?>" method="POST">
                               <?php echo e(csrf_field()); ?>

                               <?php echo e(method_field('DELETE')); ?>

                               <center><button class="btn btn-rounded btn-info mb-3" type="submit"><i class="fa fa-check"></i>-Si</button>
                                  <button class="btn btn-rounded btn-danger mb-3" type="button" data-dismiss="modal"><i class="fa fa-close"></i>-No</button></a></center>
                          </form>
                            </div>

                          </div>
                      </div>
                       </div>
                       <div class="modal-footer">


                       </div>
                     </div>
                   </div>
                 </div>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

      </div>
     </div>

     <!--modal para la alta-->
       <div class="modal fade" id="exampleModal20" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header" style="background:#2ECC71;">
              <h5 class="modal-title" id="exampleModalLabel" style="color:white;">Formulario de Alta</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="<?php echo e(route('alta')); ?>" method="post">
               <?php echo e(csrf_field()); ?>

               <div class="form-group">
                  <label for="exampleInputEmail1">Nombre</label>
                  <input type="text" name="nombre" class="form-control" id="exampleInputEmail1" required>
                  <!--<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
                </div>
                <div class="form-group">
                   <label for="exampleInputEmail1">Teléfono</label>
                   <input type="text" name="telefono" class="form-control" id="exampleInputEmail1" required>
                   <!--<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
                 </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Correo</label>
                  <input type="email" name="correo" class="form-control" id="exampleInputPassword1" required>
                </div>
                 <input type="hidden" name="activo" value="1">
                <button type="submit" class="btn btn-primary">Enviar</button>
             </form>
            </div>
            <div class="modal-footer">


            </div>
          </div>
        </div>
      </div>

    </body>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script>

     $(document).ready(function () {
     $('#entradafilter').keyup(function () {
        var rex = new RegExp($(this).val(), 'i');
      $('.contenidobusqueda tr').hide();
      $('.contenidobusqueda tr').filter(function () {
          return rex.test($(this).text());
      }).show();

      })

    });

   </script>
   <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <script>
    <?php if(Session::has('message')): ?>
        var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
        switch(type){
            case 'info':
                toastr.info("<?php echo e(Session::get('message')); ?>");
                break;

            case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;
            case 'success':
                toastr.success("<?php echo e(Session::get('message')); ?>");
                break;
            case 'error':
                toastr.error("<?php echo e(Session::get('message')); ?>");
                break;
        }
    <?php endif; ?>
    </script>
</html>
<?php /**PATH C:\xampp\htdocs\ABC\resources\views/catalogo.blade.php ENDPATH**/ ?>